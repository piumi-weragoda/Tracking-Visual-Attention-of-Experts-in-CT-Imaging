using System.Reflection;
using System.Runtime.InteropServices;

namespace EyeTest
{
    public partial class Form1 : Form
    {
        [DllImport("user32.dll")]
        public static extern bool GetCursorPos(out POINT lpPoint);
        public Point lastKnownValue = new Point();
        public Form1()
        {
            InitializeComponent();
        }

        public static Point GetCursorPosition()
        {
            POINT lpPoint;
            GetCursorPos(out lpPoint);
            // NOTE: If you need error handling
            // bool success = GetCursorPos(out lpPoint);
            // if (!success)

            return lpPoint;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = !timer1.Enabled;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Point p = GetCursorPosition();
            try
            {

                if (lastKnownValue.X != p.X || lastKnownValue.Y != p.Y)
                {
                    saveToFile(p);
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

            textBox1.Text = "(" + p.X + "," + p.Y + ")";
        }

        private string projectDirectory()
        {

            string assemblyLocation = Assembly.GetExecutingAssembly().Location;
            string directoryPath = Path.GetDirectoryName(assemblyLocation);

            // Traverse up to find the .csproj file
            string projectDirectory = directoryPath;
            while (!Directory.EnumerateFiles(projectDirectory, "*.csproj", SearchOption.TopDirectoryOnly).Any())
            {
                projectDirectory = Directory.GetParent(projectDirectory).FullName;
            }

            Console.WriteLine($"Project directory: {projectDirectory}");
            return projectDirectory;
        }

        private void saveToFile(Point p)
        {
            lastKnownValue = p;
            string path = projectDirectory();
            string filePath = path + "\\data.csv";

            using (StreamWriter writer = new StreamWriter(filePath, true))
            {
                // Write the header
                if (new FileInfo(filePath).Length == 0)
                {
                    //writer.WriteLine("Name,Age");
                    writer.WriteLine("X,Y, Timestamp");
                }
                // Write the data
                //writer.WriteLine($"{p.X},{p.Y},{DateTime.Now}");
                writer.WriteLine($"{p.X},{p.Y},{DateTime.Now.ToString("yyyy/MM/dd HH: mm:ss:fff")}");

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct POINT
    {
        public int X;
        public int Y;

        public static implicit operator Point(POINT point)
        {
            return new Point(point.X, point.Y);
        }
    }

}
